package com.exercicio.cardsbattle.model.skills;

public enum SkillModel {
    ACTION,
    STATE
}