package com.exercicio.cardsbattle.model.skills;

public enum SkillType {

    DAMAGE,
    DEFENSE,
    HEAL,
    ATTACK,
    POISON,
    CURE_POISON,
    PARALYZE,
    SPY,
    DISPEL
}
